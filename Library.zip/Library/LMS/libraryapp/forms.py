from django import forms
from .models import User


class MyLoginForm(forms.Form):
   username = forms.CharField()
   password = forms.CharField(widget=forms.PasswordInput)

class UserRegistrationForm(forms.ModelForm):
   #the only check we have to do is to compare the password
   #creating a charfield object by passing values into the constructor
   password = forms.CharField(label="Password",widget=forms.PasswordInput)
   password2=forms.CharField(label="confirm password",widget=forms.PasswordInput)




   class Meta:
       model = User
       fields = ('username', 'first_name', 'last_name', 'email', 'password')