from django.shortcuts import render

# Create your views here.

from django.shortcuts import render,HttpResponse,get_object_or_404

from .forms import MyLoginForm,UserRegistrationForm
from django.contrib.auth import logout

from django.contrib.auth import authenticate,login
# Create your views here.

def main(request):
    return render(request, 'mainpage.html')

def userhomepage(request):
    return render(request, 'userhomepage.html')



from django.shortcuts import redirect
from django.contrib.auth import authenticate, login
from django.http import HttpResponse


def user_login(request):
    if request.method == 'POST':
        login_form = MyLoginForm(request.POST)
        if login_form.is_valid():
            cleaned_data = login_form.cleaned_data
            auth_user = authenticate(request, username=cleaned_data['username'], password=cleaned_data['password'])

            if auth_user is not None:
                login(request, auth_user)

                # Redirect based on the username
                if auth_user.username == 'admin':  # Admin login
                    return redirect('home_path')  # Change 'adminpage' to your admin page URL name
                else:
                    return redirect('userhomepage')  # Change 'userhomepage' to your user homepage URL name

            else:
                return HttpResponse('Not Authenticated')
    else:
        login_form = MyLoginForm()

    return render(request, 'useraccount/login_form.html', {'login_form': login_form})


def register(request):
   if request.method == 'POST':
       user_reg_form = UserRegistrationForm(request.POST)
       #checking if the post request parameters are valid...
       if user_reg_form.is_valid():
           #receive the data, create the form, do not save it .. just keep the data
           new_user = user_reg_form.save(commit=False)
           # set the password field with the cleaned data for password
           new_user.set_password(user_reg_form.cleaned_data['password'])
           # permanently save the new user model data into database
           new_user.save()
           return render(request, 'account/register_done.html', {'user_reg_form': user_reg_form})
   else:
        user_reg_form = UserRegistrationForm()
   return render(request, 'account/register.html', {'user_reg_form': user_reg_form})


def user_logout_view(request):
    logout(request)
    return redirect('main')
